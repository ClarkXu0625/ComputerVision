# COSI-159A: Deep Learning Practice

COSI-159A: Computer Vision, 2023 Spring  
Code template on MNIST classification from 02/08 class
